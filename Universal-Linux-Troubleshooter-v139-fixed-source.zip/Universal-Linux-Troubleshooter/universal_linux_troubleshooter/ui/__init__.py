"""Qt user-interface package."""
